-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 12, 2024 at 12:08 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.4.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `proj`
--

-- --------------------------------------------------------

--
-- Table structure for table `chance`
--

CREATE TABLE `chance` (
  `id` int(11) NOT NULL,
  `shomare` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `chance`
--

INSERT INTO `chance` (`id`, `shomare`) VALUES
(1, '0'),
(2, '0'),
(3, '0'),
(4, '0'),
(5, ''),
(6, ''),
(7, '9339615304'),
(8, '9339615304'),
(9, ''),
(10, ''),
(11, '858585'),
(12, '858585'),
(13, '858585'),
(14, '858585'),
(15, ''),
(16, '454545'),
(17, ''),
(18, ''),
(19, ''),
(20, ''),
(21, '');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `username` text NOT NULL,
  `password` int(20) NOT NULL,
  `tell` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `password`, `tell`) VALUES
(1, 'arshia', 123, 2147483647),
(2, 'arshia', 123, 2147483647),
(3, '', 0, 0),
(4, '', 0, 0),
(5, 'ارشیا', 123456, 2147483647),
(6, 'ارشیا', 123456, 2147483647),
(7, '', 0, 0),
(8, '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `sabtname`
--

CREATE TABLE `sabtname` (
  `id` int(10) NOT NULL,
  `nameandfamily` text NOT NULL,
  `fathername` text NOT NULL,
  `tavalod` int(20) NOT NULL,
  `phone` int(15) NOT NULL,
  `entekhab` int(10) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` int(40) NOT NULL,
  `addres` text NOT NULL,
  `city` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sabtname`
--

INSERT INTO `sabtname` (`id`, `nameandfamily`, `fathername`, `tavalod`, `phone`, `entekhab`, `email`, `password`, `addres`, `city`) VALUES
(1, 'arshia', 'gngng', 0, 2147483647, 0, 'arshia@gmail.com', 2424, ' 4242', 'داراب'),
(2, 'arshia', 'gngng', 222, 2147483647, 0, 'arshia@gmail.com', 2424, ' 4242', 'داراب'),
(3, 'arshia', 'arash', 2222, 2147483647, 0, 'arshia@gmail.com', 123456789, ' shiraz', 'شیراز'),
(4, '', '', 0, 0, 0, '', 0, '', ''),
(5, '', '', 0, 0, 0, '', 0, '', ''),
(6, '', '', 0, 0, 0, '', 0, '', ''),
(7, '', '', 0, 0, 0, '', 0, '', ''),
(8, '', '', 0, 0, 0, '', 0, '', ''),
(9, '', '', 0, 0, 0, '', 0, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `suggestion`
--

CREATE TABLE `suggestion` (
  `id` int(11) NOT NULL,
  `suggestion` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `suggestion`
--

INSERT INTO `suggestion` (`id`, `suggestion`) VALUES
(1, ''),
(2, 'سلام'),
(3, ''),
(4, '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chance`
--
ALTER TABLE `chance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sabtname`
--
ALTER TABLE `sabtname`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `suggestion`
--
ALTER TABLE `suggestion`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chance`
--
ALTER TABLE `chance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `sabtname`
--
ALTER TABLE `sabtname`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `suggestion`
--
ALTER TABLE `suggestion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
