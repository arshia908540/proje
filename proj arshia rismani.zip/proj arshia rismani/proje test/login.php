<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login.Phone_abi</title>
  <link rel="stylesheet" href="form.css">
  <link rel="stylesheet" href="Home.css">
  <link rel="stylesheet" href="index.css">
  <link rel="stylesheet" href="table.css">
  <link rel="stylesheet" href="login.css">
  <link rel="stylesheet" href="login Responsive.css">
  <style type="text/css" rel="stylesheet">
    html{
      background-image: url(img/elijah-hail-iuUV2cUaT3c-unsplash.jpg);
    }
    a:hover {
      color: #2c6b7f;
      font-weight: 900;
      border-bottom: 2px solid #25282f;
    }
    input.shomare {
      direction: rtl;
      background-color: #00a0ff00;
      border: 2px inset;
      border-radius: 7px;
      font-size: 16px;
      margin-left: -247px;
      color: aliceblue;
    }
    input.btnshomare {
      direction: rtl;
      background-color: #e8e8e8;
      border: 2px inset;
      border-radius: 7px;
      font-size: 16px;
      font-weight: bold;
      margin-left: 144px;
    }
    li {
      list-style-type: none;
      float: right;
      margin-left: 14px;
      padding: 47px;
      margin-top: -31px;
    }
    #abi {
      width: 65px;
      height: 65px;
      padding-top: -19px;
      padding-left: 175px;
      padding-bottom: -19px;
      margin-top: -98px;
      display: block;
    }
    a#tell {
      width: 65px;
      height: 65px;
      padding-top: -19px;
      padding-left: 108px;
      padding-bottom: -19px;
      margin-top: -83px;
      display: block;
    }
    a.hamrah {
      padding: 6px;
      font-size: 18px;
      color: rgb(0 113 181);
      width: 201px;
      padding-top: -19px;
      padding-left: 60px;
      padding-bottom: -19px;
      display: block;
      margin-top: -105px;
    }
    a.sabet {
      padding: 3px;
      font-size: 18px;
      color: rgb(0 113 181);
      width: 500px;
      padding-top: -19px;
      padding-left: 93px;
      padding-bottom: -19px;
      margin-top: -48px;
      display: block;
    }
    .footer {
      background-color: #012231;
      height: 173px;
      bottom: 0px;
      position: absolute;
      /* border-radius: 35px; */
      width: 100%;
      margin-bottom: -43px;
      margin-left: -10px;
    }
    .col4 {
      background-color: #292c33;
      bottom: 0;
      text-align: center;
      padding: 71px;
      /* border-radius: 19px; */
      width: 1482px;
      height: 9px;
      margin-bottom: -194px;
      position: absolute;
      display: block;
      margin-left: -150px;
    }
  </style>

</head>
<body>
<div class="container">
  <div class="wellCome">WellCome to our store!</div>
  <div class="header">
    <div class="logo">
      <a href="img/543.png"><img class="ll" src="img/543.png"/></a>
    </div>
    <div class="menu">
      <ul>
        <li class="lii" ><a class="li"  href="home.php">خانه</a></li>
        <li class="li"><a class="li"  href="table.php">لیست موجودی</a></li>
        <li class="li"><a class="li"  href="form.php">ثبت نام در سایت</a></li>
        <li class="li"><a class="li"  href="pishnahad.php">پیشنهادات و انتقادات</a></li>
        <li class="li"><a class="li"  href="login.php">ورود به سایت</a></li>
      </ul>
    </div>
  </div>
  <form id="login" method="post" action="login.php">
<div class="login">
  <fieldset class="lofild">
    <legend class="legend">حساب کاربری</legend>

      <label>       <span class="loginsp">*</span> نام کاربری : </label>
      <br>
      <input id="loginname" type="text" name="username" placeholder="نام کاربری" required>
      <br>
      <br>
      <label>  <span class="loginsp">*</span> رمز عبور خود را وارد کنید  : </label>
      <br>
      <input id="loginpass" type="password" name="password" placeholder="رمز عبور" required>
      <br>
      <br>
      <label> <span class="loginsp">*</span>   شماره موبایل خود را وارد کنید : </label>
      <br>
      <input id="logintel" type="tel" name="tell" placeholder="شماره موبایل" required>
      <br>

      <input class="resetbtnform" type="reset" value="بازنشانی" >
      <input class="subbtnform" type="submit" value="تایید ">
  </fieldset>
</div>
  </form>


  <div class="footer">
    <div class="col1"><h3><a href="#">تماس با ما </a></h3>

      <img class="calls" src="img/call.png" height="170" width="296"/>

      <p class="telephone" > <a class="sabet"> تلفن ثابت: 32335106</a></p>
      <img class="callh" src="img/calll.png" height="536" width="860"/>
      <p class="mobile">  <a class="hamrah" >تلفن همراه: 09339615304   </a></p>
    </div>
    <div class="col2"><h3><a href="#">شبکه های اجتماعی</a></h3>
      <img class="insta" src="img/images.png" height="225" width="225"/>
      <p><a href="https://instagram.com/phone_abi?utm_m" id="abi">@Phone_abi</a></p>

      <img class="telegram" src="img/telegram-minimal-logo.png" height="300" width="300"/>
      <p class="tell"><a href="https://telegram.com" id="tell">@Phone_abi.channel</a></p>
    </div>
    <div class="col3"><h3><a href="#">درباره ی ما </a></h3>
      <P class="about"> موبایل آبی یکی از معتبر ترین سایت های خرید گوشی با مشاوره ی 24 ساعته و کاملا رایگان است و از سال 1390 شروع به کار در قسمت تعمیرات و فروش تخصصی موبایل کرد با اخرین اخبار با ما همراه باشید</P>
    </div>
  </div>

  <div class="col4"><h4>برای شرکت در قرعه کشی و آگاه شدن از تخفیف های هفتگی, شماره تلفن خود را وارد کنید</h4>
    <form method="post" action="login.php">
      <input class="shomare" type="tel" name="shomare" placeholder="9339625304">
      <input class="btnshomare" type="submit" value="تایید " name="sub">
    </form>
  </div>
</div>
</body>
</html>
<?php

$connection = mysqli_connect("localhost", "root", "", "proj");

if ($connection->connect_error) {
    die("اتصال به دیتابیس ناموفق بود: " . $connection->connect_error);
}

$username = $_POST["username"];
$password = $_POST["password"];
$tell = $_POST["tell"];

$sql = "INSERT INTO login (username, password, tell) VALUES ('$username', '$password', '$tell')";

if ($connection->query($sql) === TRUE) {

    echo '<script> alert("شما با موفقیت وارد شدید."); </script>';
} else {
    echo "خطا: " . $sql . "<br>" . $connection->error;
}

// دریافت اطلاعات از فرم
$shomare = $_POST["shomare"];


// اجرای کوئری INSERT
$sql = "INSERT INTO chance (shomare) 
VALUES ('$shomare')";


if ($connection->query($sql) === TRUE) {
    echo "good";
} else {
    echo "خطا: " . $sql . "<br>" . $connection->error;
}
$connection->close();
?>

?>