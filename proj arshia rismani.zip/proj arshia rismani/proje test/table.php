<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>list.Phone_abi</title>
  <link rel="stylesheet" href="table.css">
  <link rel="stylesheet" href="index.css">
  <link rel="stylesheet" href="Home.css">
  <link rel="stylesheet" href="table Responsive.css">

<style type="text/css" rel="stylesheet">

  a.home {
    text-decoration: none;
    font-weight: 900;
    font-size: inherit;
  }
  a.home:hover{
    color: darkred;
    font-weight: 900;
    border-bottom: 2px solid #25282f;
  }
  .footer {
    background-color: #012231;
    height: 177px;
    bottom: -139px;
    position: absolute;
    width: 100%;
    margin-left: -6px;
  }

  .col4 {
    background-color: #292c33;
    bottom: -78px;
    text-align: center;
    padding: 71px;
    /* border-radius: 19px; */
    width: 100%;
    height: 9px;
    margin-bottom: -212px;
    position: absolute;
    display: block;
    margin-left: -150px;
  }
  li {
    list-style-type: none;
    float: right;
    margin-left: 14px;
    padding: 47px;
    margin-top: -31px;
  }
  #abi {
    width: 65px;
    height: 65px;
    padding-top: -19px;
    padding-left: 175px;
    padding-bottom: -19px;
    margin-top: -98px;
    display: block;
  }
  a#tell {
    width: 65px;
    height: 65px;
    padding-top: -19px;
    padding-left: 108px;
    padding-bottom: -19px;
    margin-top: -83px;
    display: block;
  }
  a.hamrah {
    padding: 6px;
    font-size: 18px;
    color: rgb(0 113 181);
    width: 201px;
    padding-top: -19px;
    padding-left: 60px;
    padding-bottom: -19px;
    display: block;
    margin-top: -105px;
  }
  a.sabet {
    padding: 3px;
    font-size: 18px;
    color: rgb(0 113 181);
    width: 500px;
    padding-top: -19px;
    padding-left: 93px;
    padding-bottom: -19px;
    margin-top: -48px;
    display: block;
  }
  .title {
    text-align: center;
    color: #012231;
    font-weight: bolder;
    background-image: radial-gradient(#cad3dd, transparent);
  }
  tr:hover {
    background-color: #2c6b7f;
    font-size: 18px;
    font-weight: 900;
    color: white;
  }
  html{
    background-image: url(img/elijah-hail-iuUV2cUaT3c-unsplash.jpg);
  }
  th {
    background-color: #0b4c63ad;
    color: #00080c;
  }
  tr{
    background-color: rgb(255 255 255 / 15%);
  }
  tr:nth-child(even) {
    background-color: rgb(255 255 255 / 18%);
  }

</style>

</head>
<body>
<div class="container">
  <div class="wellCome">WellCome to our store!</div>
  <div class="header">
    <div class="logo">
      <a href="img/543.png"><img class="ll" src="img/543.png"/></a>
    </div>
    <div class="menu">
      <ul>
        <li class="lii" ><a class="li"  href="home.php">خانه</a></li>
        <li class="li"><a class="li"  href="table.php">لیست موجودی</a></li>
        <li class="li"><a class="li"  href="form.php">ثبت نام در سایت</a></li>
        <li class="li"><a class="li"  href="pishnahad.php">پیشنهادات و انتقادات</a></li>
        <li class="li"><a class="li"  href="login.php">ورود به سایت</a></li>
      </ul>
    </div>
  </div>
  <div class="main">
    <div class="table">
      <br>
      <h2 class="title">موجودی</h2>
      <table>
        <thead>
        <tr>
          <th>Available</th>
          <th>Price</th>
          <th>Ram</th>
          <th>Memory</th>
          <th>Phone</th>
        </tr>
        </thead>
        <tbody>
        <tr>
          <td>12</td>
          <td>6.400.000</td>
          <td>4</td>
          <td>128 gig</td>
          <td><a title="click here" class="home" href="home.php"> Poco x3</a></td>
        </tr>
        <tr>
          <td>1</td>
          <td>12.800.000</td>
          <td>12</td>
          <td>512 gig</td>
           <td><a title="click here" class="home" href="home.php">Galaxy Z fold</a></td>
        </tr>
        <tr>
          <td>6</td>
          <td>30.200.000</td>
          <td>12</td>
          <td>256 gig</td>
          <td><a title="click here" class="home" href="home.php">S 21 ultra</a></td>
        </tr>
        <tr>
          <td>14</td>
          <td>33.800.000</td>
          <td>6</td>
          <td>128 gig</td>
          <td><a title="click here" class="home" href="home.php">Iphone 12</a></td>
        </tr>
        </tbody>
      </table>
    </div>
  </div>
  <br>
  <div class="footer">
    <div class="col1"><h3><a href="#">تماس با ما </a></h3>

      <img class="calls" src="img/call.png" height="170" width="296"/>

      <p class="telephone"> <a class="sabet"> تلفن ثابت: 32335106</a></p>
      <img class="callh" src="img/calll.png" height="536" width="860"/>
      <p class="mobile">  <a class="hamrah" >تلفن همراه: 09339615304   </a></p>
    </div>
    <div class="col2"><h3><a href="#">شبکه های اجتماعی</a></h3>
      <img class="insta" src="img/images.png" height="225" width="225"/>
      <p><a href="https://instagram.com/phone_abi?utm_m" id="abi">@Phone_abi</a></p>

      <img class="telegram" src="img/telegram-minimal-logo.png" height="300" width="300"/>
      <p class="tell"><a href="https://telegram.com" id="tell">@Phone_abi.channel</a></p>
    </div>
    <div class="col3"><h3><a href="#">درباره ی ما </a></h3>
      <P class="about"> موبایل آبی یکی از معتبر ترین سایت های خرید گوشی با مشاوره ی 24 ساعته و کاملا رایگان است و از سال 1390 شروع به کار در قسمت تعمیرات و فروش تخصصی موبایل کرد با اخرین اخبار با ما همراه باشید</P>
    </div>
  </div>

  <div class="col4"><h4>برای شرکت در قرعه کشی و آگاه شدن از تخفیف های هفتگی, شماره تلفن خود را وارد کنید</h4>
    <form method="post" action="table.php">
      <input class="shomare" type="tel" name="shomare" placeholder="9339625304">
      <input class="btnshomare" type="submit" value="تایید " name="sub">
    </form>
  </div>


</div>
</body>
</html>
<?php
$connection = mysqli_connect("localhost", "root", "", "proj");

if ($connection->connect_error) {
    die("اتصال به دیتابیس ناموفق بود: " . $connection->connect_error);
}

// دریافت اطلاعات از فرم
$shomare = $_POST["shomare"];


// اجرای کوئری INSERT
$sql = "INSERT INTO chance (shomare) 
VALUES ('$shomare')";


if ($connection->query($sql) === TRUE) {
    echo "good";
} else {
    echo "خطا: " . $sql . "<br>" . $connection->error;
}

// بستن اتصال به دیتابیس
$connection->close();
?>