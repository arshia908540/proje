<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Your idea.Phone_abi</title>
    <link rel="stylesheet" href="index.css">
    <link rel="stylesheet" href="table.css">
    <style type="text/css" rel="stylesheet">

        img.instaa {
            width: 65px;
            height: 65px;
            padding-top: -23px;
            padding-left: 269px;
            padding-bottom: 28px;
            margin-top: -19px;
        }
        img.telegramm {
            width: 35px;
            height: 35px;
            padding-top: -23px;
            padding-left: 286px;
            padding-bottom: 28px;
            margin-top: -47px;
        }
        li {
            list-style-type: none;
            float: right;
            margin-left: 14px;
            padding: 47px;
            margin-top: -31px;
        }
        label {
            color: #e8e8e8;
            font-weight: 900;
            height: 72px;
            display: block;
            text-align: center;
            font-size: 26px;
            margin-top: -49px;
            border: 4px;
            border-radius: 10px;
            width: 100%;
            /* margin-left: 459px; */
            background-image: radial-gradient(#012231, #eee0);
        }
        textarea#address {
            direction: rtl;
            background-color: #d2d2d21a;
            color: #e8e8e8;
            font-weight: 900;
            margin-left: -2px;
            font-size: 24px;
            height: 165px;
            text-align: center;
            width: 1500px;
        }
        button.pishh {
            padding: 10px 20px;
            background-color: #2c6b7f;
            color: white;
            font-weight: bold;
            margin-right: 5px;
            float: left;
        }
        input.pishreset[type="reset"] {
            padding: 10px 20px;
            background-color:  #69000d;
            color: white;
            font-weight: 700;
            margin-right: 28%;
        }
        input.pishreset:hover {
            color: black;
        }
        input.pish[type="submit"] {
            padding: 10px 20px;
            background-color:#012231;
            color: white;
            font-weight: bold;
            float: left;
            margin-right: 5px;
        }
        button.pishh:hover {
            color: rgb(1 34 49);
        }
        .col4 {
            background-color: #292c33;
            bottom: 0;
            text-align: center;
            padding: 71px;
            /* border-radius: 19px; */
            width: 1482px;
            height: 9px;
            margin-bottom: -191px;
            position: absolute;
            display: block;
            margin-left: -150px;
        }
        #abi {
            width: 65px;
            height: 65px;
            padding-top: -19px;
            padding-left: 175px;
            padding-bottom: -19px;
            margin-top: -98px;
            display: block;
        }
        a#tell {
            width: 65px;
            height: 65px;
            padding-top: -19px;
            padding-left: 108px;
            padding-bottom: -19px;
            margin-top: -83px;
            display: block;
        }
        a.hamrah {
            padding: 6px;
            font-size: 18px;
            color: rgb(0 113 181);
            width: 201px;
            padding-top: -19px;
            padding-left: 60px;
            padding-bottom: -19px;
            display: block;
            margin-top: -105px;
        }
        a.sabet {
            padding: 3px;
            font-size: 18px;
            color: rgb(0 113 181);
            width: 500px;
            padding-top: -19px;
            padding-left: 93px;
            padding-bottom: -19px;
            margin-top: -48px;
            display: block;
        }
        .footer {
            background-color: #012231;
            height: 171px;
            bottom: 496px;
            position: absolute;
            /* border-radius: 35px; */
            width: 100%;
            margin-bottom: -536px;
            margin-left: -7px;
        }

        html{
            background-image: url(img/elijah-hail-iuUV2cUaT3c-unsplash.jpg);
        }
        p.aboutt {
            text-align: center;
            font-size: 17px;
            color: rgb(0 113 181);
            font-weight: bolder;
        }

    </style>
    <link rel="stylesheet" href="pishnahad Responsive.css">
    <link rel="stylesheet" href="Home.css">

</head>
<body>
<div class="container">
    <div class="wellCome">WellCome to our store!</div>
    <div class="header">
        <div class="logo">
            <a href="img/543.png"><img class="ll" src="img/543.png"/></a>
        </div>
        <div class="menu">
            <ul>
                <li class="lii" ><a class="li"  href="home.php">خانه</a></li>
                <li class="li"><a class="li"  href="table.php">لیست موجودی</a></li>
                <li class="li"><a class="li"  href="form.php">ثبت نام در سایت</a></li>
                <li class="li"><a class="li"  href="pishnahad.php">پیشنهادات و انتقادات</a></li>
                <li class="li"><a class="li"  href="login.php">ورود به سایت</a></li>
            </ul>
        </div>

        <br>
        <br>
        <br>
        <br>

    <div>
        <form method="post" action="pishnahad.php"">
        <label for="address">پیشنهادات و انتقادات خود را بنویسید</label></td>
        <td><textarea name="suggestion" cols="210" rows="10" id="address"></textarea></td>
            <div>
                <input  type="submit" class="pish" value="ارسال دیتا">
                <input class="pishreset" type="reset" value="بازنشانی صفحه">


            </div>
        </form>
    </div>

</div>
    <br>
    <br>


    <div class="footer">
        <div class="col1"><h3><a href="#">تماس با ما </a></h3>

            <img class="calls" src="img/call.png" height="170" width="296"/>

            <p class="telephone"> <a class="sabet"> تلفن ثابت: 32335106</a></p>
            <img class="callh" src="img/calll.png" height="536" width="860"/>
            <p class="mobile">  <a class="hamrah" >تلفن همراه: 09339615304   </a></p>
        </div>
        <div class="col2"><h3><a href="#">شبکه های اجتماعی</a></h3>
            <img class="instaa" src="img/images.png" height="225" width="225"/>
            <p><a href="https://instagram.com/phone_abi?utm_m" id="abi">@Phone_abi</a></p>

            <img class="telegramm" src="img/telegram-minimal-logo.png" height="300" width="300"/>
            <p class="tell"><a href="https://telegram.com" id="tell">@Phone_abi.channel</a></p>
        </div>
        <div class="col3"><h3><a href="#">درباره ی ما </a></h3>
            <P class="aboutt"> موبایل آبی یکی از معتبر ترین سایت های خرید گوشی با مشاوره ی 24 ساعته و کاملا رایگان است و از سال 1390 شروع به کار در قسمت تعمیرات و فروش تخصصی موبایل کرد با اخرین اخبار با ما همراه باشید</P>
        </div>
    </div>

    <div class="col4"><h4>برای شرکت در قرعه کشی و آگاه شدن از تخفیف های هفتگی, شماره تلفن خود را وارد کنید</h4>
        <form action="pishnahad.php" method="post">
            <input class="shomare" type="tel" name="shomare" placeholder="9339625304">
            <input class="btnshomare" type="submit" value="تایید " name="sub">
        </form>
    </div>
</div>
</body>
</html>
<?php

$connection = mysqli_connect("localhost", "root", "", "proj");

if ($connection->connect_error) {
    die("اتصال به دیتابیس ناموفق بود: " . $connection->connect_error);
}


$suggestion = $_POST["suggestion"];


$sql = "INSERT INTO suggestion (suggestion) VALUES ('$suggestion')";

if ($connection->query($sql) === TRUE) {
    echo '<script>alert("پیشنهاد با موفقیت ثبت شد.");</script>';
} else {
    echo "خطا: " . $sql . "<br>" . $connection->error;
}

// دریافت اطلاعات از فرم
$shomare = $_POST["shomare"];


// اجرای کوئری INSERT
$sql = "INSERT INTO chance (shomare) 
VALUES ('$shomare')";


if ($connection->query($sql) === TRUE) {
    echo "good";
} else {
    echo "خطا: " . $sql . "<br>" . $connection->error;
}

$connection->close();
?>


?>