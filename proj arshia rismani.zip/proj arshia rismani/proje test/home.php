<!DOCTYPE html>
<html lang="en">
<meta charset="UTF-8">
<head>
    <title>Home.Phone_abi</title>
    <link rel="stylesheet" href="css/bootstrap.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        .container, .container-fluid, .container-xxl, .container-xl, .container-lg, .container-md, .container-sm {
            width: 102%;
            padding-right: var(--bs-gutter-x, 0.75rem);
            padding-left: var(--bs-gutter-x, -0.25rem);
            margin-right: auto;
            margin-left: auto;
        }
        .col4 {
            background-color: #292c33;
            bottom: 0;
            text-align: center;
            padding: 71px;
            border-radius: 19px;
            width: 120%;
            height: 9px;
            margin-bottom: -511px;
            position: absolute;
            display: block;
            margin-left: -150px;
        }

        .col4 {
            background-color: #292c33;
            bottom: 0;
            text-align: center;
            padding: 71px;
            border-radius: 19px;
            width: 120%;
            height: 9px;
            margin-bottom: -511px;
            position: absolute;
            display: block;
            margin-left: -150px;
        }

        div.gallery {
            margin: 5px;
            border: 1px solid rgb(255 255 255 / 15%);
            float: left;
            width: 180px;

        }

        div.gallery:hover {
            border: 1px solid #777;
        }

        div.gallery img {
            width: 100%;
            height: auto;
        }

        div.desc {
            padding: 15px;
            text-align: center;
        }

        img#iphone {
            width: 179px;
            height: 181px;
        }

        img#s21 {
            width: 189px;
            height: 181px;
        }

        img#zfold {
            width: 197px;
            height: 181px;
        }

        a.img {
            text-decoration: none;
        }

        li {
            list-style-type: none;
            float: right;
            margin-left: 14px;
            padding: 47px;
            margin-top: -17px;
        }

        a {
            text-decoration: none;
            font-weight: 900;
            font-size: 18px;
            color: currentColor;
        }

        .menu {
            width: 84%;
            float: left;
            margin-top: 1%;
        }

        .logo {
            width: 15%;
            float: right;
            border-left: 2px solid #2285c0;
            height: 119px;
        }

        br {
            clear: both;
        }

        img. {
            width: 103%;
            display: block;
            margin: -52px auto
        }

        .header {
            background-color: #d2d2d2;
            height: 119px;
        }

        .wellCome {
            background-color: #2285c0;
            color: snow;
            text-align: center;
            height: 31px;
            font-size: 25px;
            border-radius: 10px;
        }

        .footer {
            background-color: #012231;
            height: 166px;
            bottom: -366px;
            position: absolute;
            border-radius: 0px;
            width: 100%;
            margin-bottom: -23px;
        }


        .footer div {
            width: 33%;
            float: right;
        }

        .gallery {
            border: 10px solid black;
            background-color: rgb(255 255 255 / 15%);
        }

        /*////////////////////////////////////*/
        body {
            font-family: Arial, Helvetica, sans-serif;
        }

        .flip-card {
            margin-top: -515px;
            margin-left: 145px;
        }

        .flip-card {
            background-color: transparent;
            width: 300px;
            height: 300px;
            perspective: 1000px;
        }

        .flip-card-inner {
            position: relative;
            width: 100%;
            height: 100%;
            text-align: center;
            transition: transform 0.6s;
            transform-style: preserve-3d;
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
        }

        .flip-card:hover .flip-card-inner {
            transform: rotateY(180deg);
        }

        .flip-card-front, .flip-card-back {
            position: absolute;
            width: 100%;
            height: 100%;
            -webkit-backface-visibility: hidden;
            backface-visibility: hidden;
        }

        .flip-card-front {
            background-color: #bbb;
            color: black;
        }

        .flip-card-back {
            background-color: #002a36;
            color: aliceblue;
            transform: rotateY(
                    180deg
            );
        }

        /*////////////////////////////////////*/
        body {
            font-family: Arial, Helvetica, sans-serif;
        }

        .flip-card1 {
            margin-left: 559px;
            margin-top: -300px;
        }

        .flip-card1 {
            background-color: transparent;
            width: 300px;
            height: 300px;
            perspective: 1000px;
        }

        .flip-card1-inner1 {
            position: relative;
            width: 100%;
            height: 100%;
            text-align: center;
            transition: transform 0.6s;
            transform-style: preserve-3d;
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
        }

        .flip-card1:hover .flip-card1-inner1 {
            transform: rotateY(180deg);
        }

        .flip-card1-front1, .flip-card1-back1 {
            position: absolute;
            width: 100%;
            height: 100%;
            -webkit-backface-visibility: hidden;
            backface-visibility: hidden;
        }

        .flip-card1-front1 {
            background-color: #bbb;
            color: black;
        }

        .flip-card1-back1 {
            background-color: #002a36;
            color: aliceblue;
            transform: rotateY(
                    180deg
            );
        }

        /*////////////////////////////////////*/
        body {
            font-family: Arial, Helvetica, sans-serif;
        }

        .flip-card2 {
            margin-left: 983px;
            margin-top: -300px;
        }

        .flip-card2 {
            background-color: transparent;
            width: 300px;
            height: 300px;
            perspective: 1000px;
        }

        .flip-card2-inner2 {
            position: relative;
            width: 100%;
            height: 100%;
            text-align: center;
            transition: transform 0.6s;
            transform-style: preserve-3d;
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
        }

        .flip-card2:hover .flip-card2-inner2 {
            transform: rotateY(180deg);
        }

        .flip-card2-front2, .flip-card2-back2 {
            position: absolute;
            width: 100%;
            height: 100%;
            -webkit-backface-visibility: hidden;
            backface-visibility: hidden;
        }

        .flip-card2-front2 {
            background-color: #bbb;
            color: black;
        }

        .flip-card2-back2 {
            background-color: #002a36;
            color: aliceblue;
            transform: rotateY(
                    180deg
            );
        }

        p.tell {
            margin-bottom: 84px;
        }

        #abi {
            width: 65px;
            height: 65px;
            padding-top: -19px;
            padding-left: 175px;
            padding-bottom: -19px;
            margin-top: -39px;
            display: block;
            color: black;
        }

        a#tell {
            width: 65px;
            height: 65px;
            padding-top: -19px;
            padding-left: 108px;
            padding-bottom: -19px;
            margin-top: -62px;
            display: block;
            color: black;
        }

        a.hamrah {
            padding: 6px;
            font-size: 19px;
            color: rgb(0 113 181);
            width: 320px;
            padding-top: -19px;
            padding-left: 57px;
            padding-bottom: -19px;
            display: block;
            margin-top: -4px;
        }

        a.sabet {
            padding: 3px;
            font-size: 18px;
            color: rgb(0 113 181);
            width: 500px;
            padding-top: -19px;
            padding-left: 93px;
            padding-bottom: -19px;
            margin-top: -22px;
            display: block;
        }
        h4 {
            color: #eee;
            font-weight: 100;
            margin-bottom: 15px;
            margin-top: -10px;
            font-size: 19px;
        }
    </style>

    <link rel="stylesheet" href="table.css">
    <link rel="stylesheet" href="index.css">
    <link rel="stylesheet" href="Home.css">
    <link rel="stylesheet" href="home Responsive.css">
    <script src="js/bootstrap.js"></script>

</head>

<div class="container-fluid">
    <div class="wellCome">WellCome to our store!</div>
    <div class="header">
        <div class="logo">
            <a href="img/543.png"><img class="ll" src="img/543.png"/></a>
        </div>
        <div class="menu">
            <ul>
                <li class="lii" ><a class="li"  href="home.php">خانه</a></li>
                <li class="li"><a class="li"  href="table.php">لیست موجودی</a></li>
                <li class="li"><a class="li"  href="form.php">ثبت نام در سایت</a></li>
                <li class="li"><a class="li"  href="pishnahad.php">پیشنهادات و انتقادات</a></li>
                <li class="li"><a class="li"  href="login.php">ورود به سایت</a></li>
            </ul>
        </div>
    </div>

    <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="img/jonas-leupe-Qpe8jEgjpvI-unsplash.jpg" class="d-block w-100" alt="...">
            </div>
            <div class="carousel-item">
                <img src="img/omar-prestwich-0TQa-Ur6Zqg-unsplash.jpg" class="d-block w-100" alt="...">
            </div>
            <div class="carousel-item">
                <img src="img/1111%20(2).jpg" class="d-block w-100" alt="...">
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls"
                data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls"
                data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>
    <div class="container1">
        <div class="gallery">
            <a class="img" target="_blank" href="img/redmi%20note%2010.png">
                <img id="redmi" src="img/redmi%20note%2010.png" width="600" height="400">
            </a>
            <hr/>
            <div class="desc"><a target="blank" href="table.php">Click here to know about note 20</a></div>
        </div>

        <div class="gallery">
            <a class="img" target="_blank" href="img/iphone%2012%20.png">
                <img id="iphone" src="img/iphone%2012%20.png" width="400" height="400">
            </a>
            <hr/>
            <div class="desc"><a target="blank" href="table.php">Click here to know about Iphone 12</a></div>
        </div>

        <div class="gallery">
            <a class="img" target="_blank" href="img/mi%2011.png">
                <img id="mi11" src="img/mi%2011.png" width="600" height="400">
            </a>
            <hr/>
            <div class="desc"><a target="blank" href="table.php">Click here to know about Mi 11</a></div>
        </div>

        <div class="gallery">
            <a class="img" target="_blank" href="img/Poco%20X3%20Pro.png">
                <img id="Poco" src="img/Poco%20X3%20Pro.png" width="600" height="400">
            </a>
            <hr/>
            <div class="desc"><a target="blank" href="table.php">Click here to know about Poco X3</a></div>
        </div>

        <div class="gallery">
            <a class="img" target="_blank" href="img/s21ultra.png">
                <img id="s21" src="img/s21ultra.png" width="600" height="400">
            </a>
            <hr/>
            <div class="desc"><a target="blank" href="table.php">Click here to know about S21 Ultra</a></div>
        </div>


        </div>
    </div>

    <div class="flip-card">
        <div class="flip-card-inner">
            <div class="flip-card-front">
                <img class="flip0" src="img/mariah-hewines-XZumQivIfFg-unsplash.jpg" alt="Avatar">
            </div>
            <div class="flip-card-back">
                <h1>AirPods</h1>
                <p>ایرپاد سری 4</p>
                <p>اتصال بی سیم با بلوتوث</p>
                <p>رنگ موجود: سفید</p>
                <p>اتصال همزمان به دو گوشی</p>
                <p>مناسب برای: مکالمه گیمینگ موزیک استفاده عمومی</p>
                <p>قیمت: 3.500.000</p>
            </div>
        </div>
    </div>

    <div class="flip-card1">
        <div class="flip-card1-inner1">
            <div class="flip-card1-front1">
                <img class="flip1" src="img/onur-binay-HLyqe4smorI-unsplash.jpg" alt="Avatar">
            </div>
            <div class="flip-card1-back1">
                <h1>Smart Watch</h1>
                <p> KW37 ساعت هوشمند کینگ ویر مدل </p>
                <p>مناسب برای:
                    آقایان و خانم‌ها</p>
                <p>صفحه نمایش لمسی</p>
                <p>رنگ های موجود: خاکستری سفید مشکی </p>
                <p>نوع کاربری:
                    ورزشی ، رسمی ، روزمره</p>
                <p>قیمت: 6.500.000</p>
            </div>
        </div>
    </div>

    <div class="flip-card2">
        <div class="flip-card2-inner2">
            <div class="flip-card2-front2">
                <img class="flip2" src="img/sebastian-banasiewcz-oXXc-s5nNy8-unsplash.jpg" alt="Avatar">
            </div>
            <div class="flip-card2-back2">
                <h1>Headphone</h1>
                <p> Sony PS4 Platinum Wireless : مدل </p>
                <p>کیفیت صدای بی‌نظیر</p>
                <p>میکروفون بسیار با کیفیت</p>
                <p>رنگ های موجود: مشکی </p>
                <p>راحتی، ایستایی و دوام استثنایی</p>
                <p>قیمت: 4.500.000</p>
            </div>
        </div>
    </div>


    <div class="footer">
        <div class="col1"><h3><a href="#">تماس با ما </a></h3>

            <img class="calls" src="img/call.png" height="170" width="296"/>

            <p><a class="sabet"> تلفن ثابت: 32335106</a></p>
            <img class="callh" src="img/calll.png" height="536" width="860"/>
            <p><a class="hamrah">تلفن همراه: 09339615304 </a></p>
        </div>
        <div class="col2"><h3><a href="#">شبکه های اجتماعی</a></h3>
            <img class="insta" src="img/images.png" height="225" width="225"/>



            <p class="insta"><a href="https://instagram.com/phone_abi?utm_m" id="abi">@Phone_abi</a></p>

            <img class="telegram" src="img/telegram-minimal-logo.png" height="300" width="300"/>
            <p class="tell"><a href="https://telegram.com" id="tell">@Phone_abi.channel</a></p>
        </div>
        <div class="col3"><h3><a href="#">درباره ی ما </a></h3>
            <P class="about"> موبایل آبی یکی از معتبر ترین سایت های خرید گوشی با مشاوره ی 24 ساعته و کاملا رایگان است و
                از سال 1390 شروع به کار در قسمت تعمیرات و فروش تخصصی موبایل کرد با اخرین اخبار با ما همراه باشید</P>
        </div>
    </div>

    <div class="col4"><h4>برای شرکت در قرعه کشی و آگاه شدن از تخفیف های هفتگی, شماره تلفن خود را وارد کنید</h4>
        <form method="post" action="home.php">
            <input class="shomare" type="tel" name="shomare" placeholder="9339625304">
            <input class="btnshomare" type="submit" value="تایید " name="sub">
        </form>
    </div>
<?php
$connection = mysqli_connect("localhost", "root", "", "proj");

if ($connection->connect_error) {
    die("اتصال به دیتابیس ناموفق بود: " . $connection->connect_error);
}

// دریافت اطلاعات از فرم
$shomare = $_POST["shomare"];


// اجرای کوئری INSERT
$sql = "INSERT INTO chance (shomare) 
VALUES ('$shomare')";


if ($connection->query($sql) === TRUE) {
    echo "good";
} else {
    echo "خطا: " . $sql . "<br>" . $connection->error;
}

// بستن اتصال به دیتابیس
$connection->close();
?>

</div>
</body>
</html>