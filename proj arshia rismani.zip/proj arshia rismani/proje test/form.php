
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sign up.Phone_abi</title>

    <link rel="stylesheet" href="index.css">
    <link rel="stylesheet" href="table.css">
    <link rel="stylesheet" href="form.css">
    <link rel="stylesheet" href="Home.css">
    <link rel="stylesheet" href="form Responsive.css">

<style type="text/css" rel="stylesheet">
    li {
        list-style-type: none;
        float: right;
        margin-left: 14px;
        padding: 47px;
        margin-top: -31px;
    }
    #abi {
        width: 65px;
        height: 65px;
        padding-top: -19px;
        padding-left: 175px;
        padding-bottom: -19px;
        margin-top: -98px;
        display: block;
    }
    a#tell {
        width: 65px;
        height: 65px;
        padding-top: -19px;
        padding-left: 108px;
        padding-bottom: -19px;
        margin-top: -83px;
        display: block;
    }
    a.hamrah {
        padding: 6px;
        font-size: 18px;
        color: rgb(0 113 181);
        width: 201px;
        padding-top: -19px;
        padding-left: 60px;
        padding-bottom: -19px;
        display: block;
        margin-top: -105px;
    }
    a.sabet {
        padding: 3px;
        font-size: 18px;
        color: rgb(0 113 181);
        width: 500px;
        padding-top: -19px;
        padding-left: 93px;
        padding-bottom: -19px;
        margin-top: -48px;
        display: block;
    }
    .footer {
        background-color: #012231;
        height: 175px;
        bottom: -96px;
        position: absolute;
        /* border-radius: 35px; */
        width: 100%;
        margin-bottom: -501px;
        margin-left: -9px;
    }
    .col4 {
        background-color: #292c33;
        bottom: 0;
        text-align: center;
        padding: 71px;
        /* border-radius: 19px; */
        width: 100%;
        height: 9px;
        margin-bottom: -748px;
        position: absolute;
        display: block;
        margin-left: -41px;
    }
    html{
        background-image: url(img/elijah-hail-iuUV2cUaT3c-unsplash.jpg);
    }
</style>

</head>
<body>

<div class="container">
    <div class="wellCome">WellCome to our store!</div>
    <div class="header">
        <div class="logo">
            <a href="img/543.png"><img class="ll" src="img/543.png"/></a>
        </div>
        <div class="menu">
            <ul>
                <li class="lii" ><a class="li"  href="home.php">خانه</a></li>
                <li class="li"><a class="li"  href="table.php">لیست موجودی</a></li>
                <li class="li"><a class="li"  href="form.php">ثبت نام در سایت</a></li>
                <li class="li"><a class="li"  href="pishnahad.php">پیشنهادات و انتقادات</a></li>
                <li class="li"><a class="li"  href="login.php">ورود به سایت</a></li>
            </ul>
        </div>
        </div>
    <br>
    <h2 class="sabtnam">برای ثبت نام در سایت اطلاعات خود را وارد کنید</h2>
<form class="form" method="post" action="form.php">
    <div class="field">
        <br>
        <label for="nameandfamily">  نام و نام خانوادگی <span class="red">*</span></label>

        <input type="text" name="nameandfamily" placeholder="نام و نام خانوادگی را وارد کنید."
               id="nameandfamily"/>
    </div>
    <div class="field">
        <label>  نام پدر <span class="red">*</span></label>

        <input type="text" name="fathername" placeholder="نام پدر:"
              id="fathername"/>
    </div>
    <div class="field">
        <label>تاریخ تولد</label>
        <input type="date" name="tavalod">
    </div>
    <div class="field">
        <label>شماره تماس خود را وارد نمایید</label>
        <input type="tel" placeholder="9339615304" pattern="{10}" NAME="phone">
    </div>
    <div class="field">
        <label>جنسیت:</label>
        <input type="radio" name="entekhab">
        <span>زن</span>
        <input type="radio" name="entekhab">
        <span>مرد</span>
    </div>

    <fieldset>
        <legend>حساب کاربری</legend>
        <div class="field">
            <label>آدرس ایمیل خود را وارد نمایید.</label>
            <br>
            <input placeholder="ali@gmail.com" type="email" NAME="email">
        </div>
        <div class="field">
            <label>رمز عبور خود را وارد نمایید.</label>
            <br>
            <input type="password" placeholder="رمز عبور خود را وارد نمایید." title="حداقل 8 کاراکتر" name="password">
        </div>
    </fieldset>
    <div class="field">
        <label>آدرس کامل خود را وارد کنید</label>
        <br>
        <textarea rows="5" cols="40" name="addres"> </textarea>
    </div>
    <div class="field">
        <label>شهر خود را انتخاب کنید.</label>
        <br>
        <select name="city">
            <option >شیراز</option>
            <option >مرودشت</option>
            <option >جهرم</option>
            <option >فسا</option>
            <option >صدرا</option>
            <option >داراب</option>
            <option >لار</option>
            <option >اباده</option>
            <option >زرقان</option>
            <option >اردکان</option>
            <option >اقلید</option>
        </select>
    </div>
    <div class="field">
        <label>میزان رضایت شما از خدمات:</label>
        <br>
        <span>0</span>
        <input type="range" id="range" value="30">
        <span>100</span><hr/>
    </div>
    <div class="field">
        <input type="submit" class="btnf" value="ارسال دیتا">
        <input type="reset" class="resetbtn" value="بازنشانی صفحه">

        <button>ذخیره دیتا</button>
    </div>
</form>
    <div class="footer">
        <div class="col1"><h3><a href="#">تماس با ما </a></h3>

            <img class="calls" src="img/call.png" height="170" width="296"/>

            <p class="telephone" > <a class="sabet"> تلفن ثابت: 32335106</a></p>
            <img class="callh" src="img/calll.png" height="536" width="860"/>
            <p class="mobile">  <a class="hamrah" >تلفن همراه: 09339615304   </a></p>
        </div>
        <div class="col2"><h3><a href="#">شبکه های اجتماعی</a></h3>
            <img class="insta" src="img/images.png" height="225" width="225"/>
            <p><a href="https://instagram.com/phone_abi?utm_m" id="abi">@Phone_abi</a></p>

            <img class="telegram" src="img/telegram-minimal-logo.png" height="300" width="300"/>
            <p class="tell"><a href="https://telegram.com" id="tell">@Phone_abi.channel</a></p>
        </div>
        <div class="col3"><h3><a href="#">درباره ی ما </a></h3>
            <P class="about"> موبایل آبی یکی از معتبر ترین سایت های خرید گوشی با مشاوره ی 24 ساعته و کاملا رایگان است و از سال 1390 شروع به کار در قسمت تعمیرات و فروش تخصصی موبایل کرد با اخرین اخبار با ما همراه باشید</P>
        </div>
    </div>

    <div class="col4"><h4>برای شرکت در قرعه کشی و آگاه شدن از تخفیف های هفتگی, شماره تلفن خود را وارد کنید</h4>
        <form id="number" method="post" action="form.php">
            <input id="shomare" type="tel" name="shomare" placeholder="9339625304">
            <input id="btnshomare" type="submit" value="تایید " name="sub">
        </form>
    </div>


</div>
</div>
</body>
</html>
<?php
$connection = mysqli_connect("localhost", "root", "", "proj");

if ($connection->connect_error) {
die("اتصال به دیتابیس ناموفق بود: " . $connection->connect_error);
}

// دریافت اطلاعات از فرم
$nameandfamily = $_POST["nameandfamily"];
$fathername = $_POST["fathername"];
$tavalod = $_POST["tavalod"];
$phone = $_POST["phone"];
$entekhab = $_POST["entekhab"];
$email = $_POST["email"];
$password = $_POST["password"];
$addres = $_POST["addres"];
$city = $_POST["city"];

// اجرای کوئری INSERT
$sql = "INSERT INTO sabtname (nameandfamily, fathername,tavalod, phone,entekhab, email, password, addres, city) 
VALUES ('$nameandfamily', '$fathername','$tavalod', '$phone','$entekhab', '$email', '$password', '$addres', '$city')";


if ($connection->query($sql) === TRUE) {
echo '<script>alert("پیشنهاد با موفقیت ثبت شد.");</script>';
} else {
echo "خطا: " . $sql . "<br>" . $connection->error;
}

// بستن اتصال به دیتابیس
$connection->close();
?>
<?php
$connection = mysqli_connect("localhost", "root", "", "proj");

if ($connection->connect_error) {
    die("اتصال به دیتابیس ناموفق بود: " . $connection->connect_error);
}

// دریافت اطلاعات از فرم
$shomare = $_POST["shomare"];


// اجرای کوئری INSERT
$sql = "INSERT INTO chance (shomare) 
VALUES ('$shomare')";


if ($connection->query($sql) === TRUE) {
    echo "good";
} else {
    echo "خطا: " . $sql . "<br>" . $connection->error;
}

// دریافت اطلاعات از فرم
$shomare = $_POST["shomare"];


// اجرای کوئری INSERT
$sql = "INSERT INTO chance (shomare) 
VALUES ('$shomare')";


if ($connection->query($sql) === TRUE) {
    echo "good";
} else {
    echo "خطا: " . $sql . "<br>" . $connection->error;
}
// بستن اتصال به دیتابیس
$connection->close();
?>
